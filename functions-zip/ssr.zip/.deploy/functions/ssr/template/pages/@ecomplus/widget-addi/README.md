# Widget Offers Notification

Storefront plugin to handle product stock and offers notification on subscription
